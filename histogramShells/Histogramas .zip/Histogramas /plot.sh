#!/bin/sh

#INICIO PLOTEO DEL PRIMER VECTOR

#####PLOTEO GRUPO1

    #Eliminar .dat existentes
    rm *.dat
    echo "Archivos eliminados"

    #Obtener las estadisticas promedio
    ./extractAverageData1.sh
    #obtener estadiscas del autor desconocido
    ./extractUnknownData1.sh

    #Generar graficas con barras de error
    echo "Graficacion de resultados"
    ./plotHistogram1.sh

#####PLOTEO GRUPO2

    #Eliminar .dat existentes
    rm *.dat
    echo "Archivos eliminados"

    #Obtener las estadisticas promedio
    ./extractAverageData2.sh
    #obtener estadiscas del autor desconocido
    ./extractUnknownData2.sh

    #Generar graficas con barras de error
    echo "Graficacion de resultados"
    ./plotHistogram2.sh

#####PLOTEO GRUPO3

   #Eliminar .dat existentes
    rm *.dat
    echo "Archivos eliminados"

    #Obtener las estadisticas promedio
    ./extractAverageData3.sh
    #obtener estadiscas del autor desconocido
    ./extractUnknownData3.sh

    #Generar graficas con barras de error
    echo "Graficacion de resultados"
    ./plotHistogram3.sh

#####PLOTEO GRUPO4

    #Eliminar .dat existentes
    rm *.dat
    echo "Archivos eliminados"

    #Obtener las estadisticas promedio
    ./extractAverageData4.sh
    #obtener estadiscas del autor desconocido
    ./extractUnknownData4.sh

    #Generar graficas con barras de error
    echo "Graficacion de resultados"
    ./plotHistogram4.sh

#####PLOTEO GRUPO4

    #Eliminar .dat existentes
    rm *.dat
    echo "Archivos eliminados"

    #Obtener las estadisticas promedio
    ./extractAverageDataNum.sh
    #obtener estadiscas del autor desconocido
    ./extractUnknownDataNum.sh

    #Generar graficas con barras de error
    echo "Graficacion de resultados"
    ./plotHistogramNum.sh


    #Eliminar .dat existentes
    rm *.dat
    echo "Archivos eliminados"
